%% regulator parameters
Kp_u = 80; %500*wn^2*T/K 
Ki_u =  0.08; %1000*wn^3*T/(10*K) 
Kd_u = 0;
e_u_limit = 0.7;
nc_max = (85*2*pi)/60;

%% referance model
zeta_u = 1;
omega_n_u = 0.005; 

